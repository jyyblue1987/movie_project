<?php

namespace App\Models\Movies;

use Illuminate\Database\Eloquent\Model;

class Device extends Model 
{
	protected 	$guarded = [];
	protected 	$table = 'devices';
	public 		$timestamps = false;
	
}