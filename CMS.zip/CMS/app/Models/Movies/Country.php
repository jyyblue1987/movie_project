<?php

namespace App\Models\Movies;

use Illuminate\Database\Eloquent\Model;

class Country extends Model 
{
	protected 	$guarded = [];
	protected 	$table = 'country';
	public 		$timestamps = false;
	
}