@extends('layout.layout')
@section('content')
<section id="intro">  
    <header>  
        <h2>Do you love flowers as much as we do?</h2>  
    </header>  
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut.</p>  
</section>  

<section>  
       <article class="blogPost">  
           <header>  
               <h2>This is the title of a blog post</h2>  
               <p>Posted on <time datetime="2009-06-29T23:31:45+01:00">June 29th 2009</time> by 
               <a href="#">Mads Kjaer</a> - <a href="#comments">3 comments</a></p>  
           </header>  
           <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin euismod tellus 
                eu orci imperdiet nec rutrum lacus blandit. Cras enim nibh, sodales ultricies 
                elementum vel, fermentum id tellus. Proin metus odio, ultricies eu pharetra 
                dictum, laoreet id odio...</p>  
       </article>  
   </section>  
@stop
