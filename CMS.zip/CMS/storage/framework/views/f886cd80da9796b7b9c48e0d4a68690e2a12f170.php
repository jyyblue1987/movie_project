<?php $__env->startSection('sidebar'); ?>
<div class="left_menu" style="background:#048cb1 !important;">
<?php
	$select_option1 = "";
	$select_option2 = "";
	$select_option3 = "";
	$confirm = explode('movies/category', URL::to('/').'/'.Route::getCurrentRoute()->getPath());	
	if(count($confirm) > 1){
		$select_option1 = "#999";
	}
	$confirm = "";
	$confirm = explode('movies/movies', URL::to('/').'/'.Route::getCurrentRoute()->getPath());	
	if(count($confirm) > 1){
		$select_option2 = "#999";
	}
	
	$confirm = "";
	$confirm = explode('movies/users', URL::to('/').'/'.Route::getCurrentRoute()->getPath());	
	if(count($confirm) > 1){
		$select_option3 = "#999";
	}
?>	

	
	<div class="eachmenu" style="margin-top:47px;margin-left:0px;">		
		<p id="setup_wizard"><i class="fa fa-gear" style="width:25px;font-size:25px"></i><span style="margin-top:-5px;font-size:15px;font-weight:bold;">&nbsp;&nbsp;MENU<span></p>
	</div>
	<div class="eachmenu" style="margin-top:37px;">		
		<a href="/backoffice/property/wizard/client"><p style="color:<?php echo $select_option1;?>">Category</p></a>
	</div>
	<div class="eachmenu">
		<img src="/images/admin_setup_icon.png" width="17px"/>
		<a href="/backoffice/admin/wizard/department"><p style="color:<?php echo $select_option2;?>">Movies</p></a>
	</div>
	<div class="eachmenu">
		<img src="/images/menu_icon_2.png"/>
		<a href="/backoffice/user/wizard/user"><p style="color:<?php echo $select_option3;?>">Admin Setup</p></a>
	</div>
	<div class="eachmenu">
		<img src="/images/menu_icon_5.png"/>
		<p style="">Log out</p>
	</div>
</div>
<?php echo $__env->yieldSection(); ?>