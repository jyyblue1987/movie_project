
	<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
	<script type="text/javascript" src="js/jquery.kwicks-1.5.1.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
    <script type="text/javascript" src="js/superfish.js"></script>
	<script type="text/javascript" src="js/touchTouch.jquery.js"></script>
	<link rel="stylesheet" href="css/touchTouch.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/kwicks-slider.css" type="text/css" media="screen">
	<script type="text/javascript" src="js/touchTouch.jquery.js"></script>

	
	 <link rel="stylesheet" media="screen" href="css/zoomple.css" type="text/css">
	 <script src="js/jquery-1.js" type="text/javascript"></script> 
	 <script src="js/zoomple.js" type="text/javascript"></script>   
	 <script type="text/javascript">
	                  
		  $(document).ready(function() { 	
			$('.zoomple').zoomple({ 
				 offset : {x:-150,y:-150},
				 zoomWidth : 300,  
				 zoomHeight : 300,
				 roundedCorners : true
				 
			});
			
		 }); 
	 </script>   
<div class="container" style="width:100%;position:relative;">
	<div class="row" style="">
		<a href="images/simulators/lens_back_2.png" class="zoomple" >
		<img class="simulator_back_2" src = "/images/simulators/lens_back_2.png"  alt="" style="width:100%"/>	
	    </a>
		<img class="simulator_opt" src = "/images/simulator_opt_bg.png" style=""/>	
	</div>
</div>
<div class="container" style="width:100%;position:relative;">
	<div class="row" style="width:auto">
		<img class="bottom_1_bg" src = "/images/bottom_bg_1.png" style=""/>
	</div>
</div>
<div class="container" style="width:100%;position:relative;">
	<div class="row" style="width:auto">
		<img class="bottom_2_bg" src = "/images/bottom_bg_2.png" style=""/>
	</div>
</div>
<!-- <div class="container" style="width:100%;position:relative;">

        <div class="flexslider">
              <ul class="slides">
				<li><img class="lands_1" src = "/images/lands/land_1.png" style=""/></li>
				<li><img class="lands_2" src = "/images/lands/land_2.png" style=""/></li>
				<li><img class="lands_3" src = "/images/lands/land_3.png" style=""/></li>
				<li><img class="lands_4" src = "/images/lands/land_4.png" style=""/></li>
				<li><img class="lands_5" src = "/images/lands/land_5.png" style=""/></li>
				<li><img class="lands_6" src = "/images/lands/land_6.png" style=""/></li>
				<span id="responsiveFlag"></span>
          </ul>
        </div>
</div> -->

