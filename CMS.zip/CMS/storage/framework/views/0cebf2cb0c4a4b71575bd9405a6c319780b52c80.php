<?php $__env->startSection('topmenu'); ?>
<link href="/css/topmenu.css" rel="stylesheet">
<header>
	<div id = "top_back">
		<div class="icon"></div>
		<div class="subject"></div>
	</div>
</header>

<?php echo $__env->yieldSection(); ?>