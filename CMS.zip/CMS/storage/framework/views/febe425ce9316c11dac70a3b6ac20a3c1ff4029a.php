<?php $__env->startSection('content'); ?>

<div id="main_column" class="clear" style="width:60%;margin-left:15%; text-align:center" align="center">
	<div class="clear mainbox-title-container">
			<h1 class="mainbox-title float-left">
				广告 
			</h1>
			<div class="tools-container">
				<span class="action-add">
					<a href="/admin/ad_register">添加图片</a>
				</span>
			</div>
	</div>

	<div class="mainbox-body">
		<div id="content_manage_users">
			<form action="/admin/ad_totaldelete" method="post">
				<div id="data_grid_view" class="grid-view">
					<div class="summary">
						全部因素: <?php echo e($users->count()); ?>

					</div>
					<table class="items">
						<thead>
							<tr>
								<th width="1%" class="center cm-no-hide-input">
									<input type="checkbox" name="check_all" value="Y" title="Check / uncheck all" class="checkbox cm-check-items" />
								</th>
								<th id="data_grid_view_c1"><a class="sort-link" href="">序号</a></th>
								<th id="data_grid_view_c1"><a class="sort-link" href="">标题</a></th>
								<th id="data_grid_view_c2"><a class="sort-link" href="">图片</a></th>
								<th id="data_grid_view_c8"><a class="sort-link" href="">最新更新</a></th>
							</tr>
						</thead>	
						<tbody>
							<?php
								$i = 1;
								foreach( $users as $value )	
								{ ?>
                                    
 									<tr class="odd">
									<td class="center cm-no-hide-input"><input type="checkbox" name="cat_ids[]" value="<?php echo e($value['id']); ?>" class="checkbox cm-item" /></td>
									<td><?php echo e($value['id']); ?></td>
									<td width="20%"><a class="view" href="/admin/ad_edit/<?php echo e($value['id']); ?>?page=<?php echo e($users->currentPage()); ?>"><?php echo e($value['title']); ?></td>
									<td><a class="view" href="/uploads/<?php echo e($value['thumbpath']); ?>" target="_blank"><?php echo e($value['thumbpath']); ?></a></td>
									<?php	
										try{
											$start = date('Y-m-d', $value['start']);
											$end = date('Y-m-d', $value['end']);
											}
										catch(Exception $e){}
									?>
																	
									<td><?php echo e($value['published']); ?></td>																		
									<td class="nowrap">
										<a class="tool-link " href="/admin/ad_edit/<?php echo e($value['id']); ?>?page=<?php echo e($users->currentPage()); ?>" >Edit</a>
										&nbsp;&nbsp;
										<ul class="cm-tools-list tools-list">
											<li><a class="cm-confirm" href="/admin/ad_delete/<?php echo e($value['id']); ?>?page=<?php echo e($users->currentPage()); ?>">Delete</a></li>
										</ul>
									</td>
							<?php 
								$i++;} 
							?>

						</tbody>
					</table>
	
					<div class="pager"><ul id="yw0" class="yiiPager">
						<?php echo $users->appends(Request::except('page'))->render(); ?>						
					</div>
				
				</div>
				<div class="buttons-container buttons-bg">
					<div class="float-left">

						
							<span  class="submit-button cm-button-main cm-confirm cm-process-items">
								<input  class="cm-confirm cm-process-items" type="submit" name="dispatch[profiles.m_delete]" value="删除" />
							</span>
					</div>
				</div>				
				
			</form>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>