<?php $__env->startSection('setting_content'); ?>

<input type="hidden" id="id" value="-1"/>

<?php echo Html::style('css/iCheck/all.css'); ?>

<?php echo Html::script('js/iCheck/icheck.min.js'); ?>

<div class="container" style="width:100%;"> 
	<div class="row"> 
		<div class="col-sm-offset-1 col-md-10"> 
			<div class="panel panel-primary"> 
				<div style="background:#509449;height:50px;padding-top:5px;">                            
					<h3 class="modal-title" style="color:#fff" id="addModalLabel">Admin Profile</h3> 
				</div>     
				<?php echo Form::open(['route' => 'post-admin-update', 'class'=>'form-horizontal']); ?>	          
				<div class="modal-body"> 
					<br> 
						<?php echo csrf_field(); ?>

						
						<?php if(Session::has('invalid_login')): ?>
							<div class="alert alert-danger col-md-12">
								<p><?php echo e(Session::get('invalid_login')); ?></p>
							</div>
						<?php endif; ?> 
						<?php if(Session::has('success')): ?>
							<div class="alert alert-success col-md-12">
								<p><?php echo Session::get('success'); ?></p>
							</div>
						<?php endif; ?>  
						
						<div class="form-group">
							<label class="control-label col-sm-4" for="client">Admin Name : </label>
							<div class="col-sm-5">
								<input type="text" class="form-control" id="name" name="name" required placeholder="admin name" value="<?php echo e($profile->username); ?>">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-4" for="client">Old Password : </label>
							<div class="col-sm-5">
								<input type="password" class="form-control" required id="opassword" name="opassword" placeholder="Old password" value="">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-4" for="client">New Password : </label>
							<div class="col-sm-5">
								<input type="password" class="form-control" required id="npassword" name="npassword" placeholder="New password" value="">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-4" for="client">Confirm Password : </label>
							<div class="col-sm-5">
								<input type="password" class="form-control" required id="cpassword" name="cpassword" placeholder="Confirm password" value="">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-4" for="client">Admin Email : </label>
							<div class="col-sm-5">
								<input type="text" class="form-control" required id="email" name="email" placeholder="Admin email" value="<?php echo e($profile->email); ?>">
							</div>
						</div>                         
				</div>                         
				<div class="modal-footer " id="createButton">
					<button type="submit" class="btn btn-success btn-sm" data-dismiss="modal">
						<span class="glyphicon glyphicon-ok"></span>
						<b> Update</b>
					</button>
				</div>
				<?php echo Form::close(); ?>   
			</div>                     
			
			
								 
		</div>                 
	</div>   
</div>		
<style>
.col-sm-12 {
	width: 100%;	
	height:500px;
	overflow-y:scroll;
}
</style>
<script>
			
</script>    


<?php $__env->stopSection(); ?>	
<?php echo $__env->make('layout.setting_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>