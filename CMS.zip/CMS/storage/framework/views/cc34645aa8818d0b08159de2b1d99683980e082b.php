<?php $__env->startSection('setting_content'); ?>
	<div style="clear:both">
		<div class="search_container" style="float:right">
			<input class="search_box sidebar_back white_color" type="text" size="15" name="search" id="search" value=""/>
			<img src="/images/admin/search_icon.png" class="input_img">
		</div>	
	</div>
	
	<div style="margin-top:70px;">
		<div class="item_container" style="margin:auto;">
			<table width=100% class="items">
				<thead>
					<tr class="table_header">
						<th width="100%"><a>Floors</a></th>					
					</tr>
				</thead>
				<tbody>
					<tr class="odd">
						<td><a>All(8)</a></td>					
					</tr>
					<tr class="even">
						<td><a>Dusit Thani Group</a></td>					
					</tr>
					<tr class="odd">
						<td><a>Hilton Hotels Middle East LTD</a></td>					
					</tr>
					<tr class="even">
						<td><a>Starwood Hotels & Resorts</a></td>					
					</tr>
					<tr class="odd">
						<td><a class="add_item"><img src="/images/admin/add_item_icon.png" onclick="add_item()"/></a></td>					
					</tr>					
				</tbody>
			</table>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.setting.setting_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>