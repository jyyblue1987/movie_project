<?php $__env->startSection('content'); ?>
	<section style="float:left;width:1159px;height:100%">
		<?php echo $__env->yieldContent('settingcontent'); ?>				
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>