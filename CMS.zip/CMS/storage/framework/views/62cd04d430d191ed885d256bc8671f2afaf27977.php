<?php $__env->startSection('content'); ?>

<div id="main_column" class="clear">
	<div class="clear mainbox-title-container">
		<h1 class="mainbox-title float-left">
			历史信息 
		</h1>
		
	</div>
	<div id="search-form" class="section-border">
		
			<table cellpadding="0" cellspacing="0" border="0" class="info_detail_view">
				<?php
                
				echo '<tr><td class="title">序号&nbsp;&nbsp;&nbsp;:</td><td class="value">'.$users['id'].'</td>
					      <td class="title">用户名称&nbsp;&nbsp;&nbsp;:</td><td class="value">'.$name.'</td></tr>';
				echo '<tr><td class="title">标题&nbsp;&nbsp;&nbsp;:</td><td class="value">'.$users['commentnum'].'</td>
				          <td class="title">被攒&nbsp;&nbsp;&nbsp;:</td><td class="value">'.$users['favonum'].'</td>
				          <td class="title">修改日期&nbsp;&nbsp;&nbsp;:</td><td class="value">'.$users['modifydate'].'</td></tr>';				
				
			?>
			</table>
		
	</div>

	<div class="mainbox-body" >
		<div id="content_manage_users">
			<form action="/admin/index" method="GET">
			<div class="col_custom" >
				<div id="" class="grid-view">
					<div class="summary" style = "text-align:left;">
						Stage:
						
					</div>
					<table class="items">
						<thead>
							<tr>
								
								<th id="data_grid_view_c1">序号</th>
								<th id="data_grid_view_c1">缩略图预览</th>
								<th id="data_grid_view_c3">标题</th>
								<th id="data_grid_view_c3">Stage日期</th>
								<!--<th id="data_grid_view_c7"><a class="sort-link" href="/index.php?r=user/admin&amp;User_sort=status">Status</a></th>-->
							</tr>
						</thead>	
						<tbody>
							<?php
								
								$i = 1;								
								foreach( $stage as $value )	
								{
									
									echo '<tr class="odd">';
									
									echo '<td>'.$value['id'].'</td>';
									echo '<td width="10%">'.$value['thumbnail'].'</td>
										<td>'.$value['content'].'</a></td>';
									
									echo '<td>'.$value['modifydate'].'</td>';
									
									$i++;
								}

							?>

						</tbody>
					</table>
					
					
				</div>
			</div>
			<div class="col_custom" style = "float:right;">
				<div id="" class="grid-view">
					<div class="summary" style = "text-align:left;">
						Comment:
						
					</div>
					<table class="items">
						<thead>
							<tr>
								
								<th id="data_grid_view_c1">序号</th>							
								<th id="data_grid_view_c3">标题</th>
								<th id="data_grid_view_c1">标题用户名称</th>
								<th id="data_grid_view_c3">标题日期</th>
								<!--<th id="data_grid_view_c7"><a class="sort-link" href="/index.php?r=user/admin&amp;User_sort=status">Status</a></th>-->
							</tr>
						</thead>	
						
					</table>
					
					
				</div>
			</div>	
				
			</form>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>