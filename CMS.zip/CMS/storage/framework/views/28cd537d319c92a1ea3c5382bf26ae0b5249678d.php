<?php $__env->startSection('content'); ?>
	<section style="float:left;width:100%;height:100%">
		<link href="/css/admin_setting.css" rel="stylesheet">
		<div id="setting_div" style="margin-top:50px;width:auto;">
			
			<div id="">
				<div id="setting_sub_content" style=" ">
				<?php $__env->startSection('setting_nav'); ?>
					<div style="clear:both;margin-top:50px;positive:relative">
						<?php echo $__env->yieldContent('setting_content'); ?>								
					</div>	
				<?php echo $__env->yieldSection(); ?>	
				
				</div>
			
			</div>	
		</div>	
	</section>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.logintop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>