<!doctype html>
<html lang="en">

	<?php echo $__env->make('layout.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<body>

		<div id = "total_div">
			<?php echo $__env->make('layout.topmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div id="content_back">
				<?php echo $__env->make('layout.leftsidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>				
				<?php echo $__env->yieldContent('content'); ?>				
			</div>
		</div>

	</body>
</html>