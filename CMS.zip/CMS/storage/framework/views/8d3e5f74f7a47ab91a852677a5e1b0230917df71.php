<?php $__env->startSection('content'); ?>
	<section style="float:left;width:1159px;height:100%">
		<link href="/css/admin_setting.css" rel="stylesheet">
		<div id="setting_div">			
			<div id="setting_sidebar" class="sidebar_back">
				<?php echo $__env->make('backoffice.wizard.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			<div id="setting_content">
				<div id="setting_sub_content">
				<?php $__env->startSection('setting_nav'); ?>
					<div class="setting_menu_group" style="margin-left:155px;">
						<?php if($errors->any()): ?>
							<h4><?php echo e($errors->first()); ?></h4>
						<?php endif; ?>
						<?php 
							$path = 'backoffice/property/wizard';
							$selected = array();
							for( $i = 0; $i < 13; $i++ )
							{
								if( $i < $step )
									array_push($selected, 'selector');
								else
									array_push($selected, '');
							}
								
						?>			
					
						<div id="section" class="settingmenu <?php echo e($selected['0']); ?>">
							<span>					
								Section
							</span>		
						</div>					
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['0']); ?>"></span>	
						</div>						
						
						<div id="admin" class="settingmenu <?php echo e($selected['1']); ?>">
							<span>						
								Admin Extn		
							</span>
						</div>
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['1']); ?>"></span>	
						</div>		
						
						<div id="guest" class="settingmenu <?php echo e($selected['2']); ?>">
							<span>						
								Guest Extn
							</span>
						</div>
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['2']); ?>"></span>	
						</div>		
						
						<div id="carrier" class="settingmenu <?php echo e($selected['3']); ?>">
							<span>						
								Carrier
							</span>
						</div>					
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['3']); ?>"></span>	
						</div>		
						
						<div id="destination" class="settingmenu <?php echo e($selected['4']); ?>">
							<span>						
								Destination
							</span>
						</div>	
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['4']); ?>"></span>	
						</div>		
						
						<div id="carrier_group" class="settingmenu <?php echo e($selected['5']); ?>">
							<span>						
								Carrier Group
							</span>
						</div>						
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['5']); ?>"></span>	
						</div>			
						
						<div id="carrier_charge" class="settingmenu <?php echo e($selected['6']); ?>">
							<span>						
								Carrier Charge
							</span>
						</div>						
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['6']); ?>"></span>	
						</div>		
						
						<div id="property_charge" class="settingmenu <?php echo e($selected['7']); ?>">
							<span>						
								Property Charge
							</span>
						</div>						
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['7']); ?>"></span>	
						</div>		
						
						<div id="tax" class="settingmenu <?php echo e($selected['8']); ?>">
							<span>						
								Tax
							</span>
						</div>
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['8']); ?>"></span>	
						</div>			
						
						<div id="allowance" class="settingmenu <?php echo e($selected['9']); ?>">
							<span>						
								Allowance
							</span>
						</div>
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['9']); ?>"></span>	
						</div>	
						
						<div id="time_slab" class="settingmenu <?php echo e($selected['10']); ?>">
							<span>						
								Time Slab
							</span>
						</div>
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['10']); ?>"></span>	
						</div>			
						
						<div id="rate_map" class="settingmenu <?php echo e($selected['11']); ?>">
							<span>						
								Rate Map1
							</span>
						</div>							
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['11']); ?>"></span>	
						</div>			
						
						<div id="rate_map" class="settingmenu <?php echo e($selected['12']); ?>">
							<span>						
								Rate Map2
							</span>
						</div>							
					</div>		
					<div style="clear:both;margin-top:150px;positive:relative">
						<?php echo $__env->yieldContent('setting_content'); ?>								
					</div>	
				<?php echo $__env->yieldSection(); ?>	
				
				</div>
			
			</div>	
		</div>	
	</section>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>