<?php $__env->startSection('setting_content'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.setting.setting_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>