<?php $__env->startSection('header'); ?>
<head>
	<meta charset="UTF-8">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	
	<title>Hotel Management</title>
	<link href="/css/form.css" rel="stylesheet">
	<link href="/css/color.css" rel="stylesheet">
	<link href="/css/dialog.css" rel="stylesheet">
	<script type='text/javascript' src='/js/jquery.min.js'></script>
	
	<!-- Upload -->
	<script type='text/javascript' src='/js/jquery.uploadfile.min.js'></script>
	<link rel="stylesheet" type="text/css" href="/css/uploadfile.css" />
	
	<script type='text/javascript' src='/js/core.js'></script>
	<script type='text/javascript' src='/js/ajax.js'></script>
	<script type='text/javascript' src='/js/funcs.js'></script>	

	<script type="text/javascript">
		$.ajaxSetup({
		  headers: {
			'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
		  }
		});
	</script>
</head>
<?php echo $__env->yieldSection(); ?>
