<?php $__env->startSection('setting_content'); ?>

<?php
	$method = "post";								
	$create = 'Submit';
	$title = "ADD A CLIENT";
	if( !empty($model->id) )
	{
		$method = "put";										
		$title = "UPDATE A CLIENT";
		$create = 'Submit';
	}

?>

<div class="item_container" style="margin:auto;height:300px">
	<div class="items">		
		<span style="float:left;margin-left:10px;margin-top:10px">
		<?php echo e($title); ?>

		</span>

	</div>		
	
	<div class="form_center">		
		<?php echo e(Form::open(array('url' => '/backoffice/property/wizard/client/' . $model->id, 'method' => $method ))); ?>

			<div id="content_general" style="margin-top:30px">
				<fieldset>
					<div class="form-field">
						<label for="name" class="cm-required">Name:</label>
						<input type="text" id="name" name="name" class="input-text" size="32" maxlength="50" value="<?php echo e($model->name); ?>" />
						<i class="name-edit fa fa-pencil"></i>
					</div>							
					<div class="form-field">
						<label for="name">Description:</label>
						<input type="text" id="desc" name="description" class="input-text" size="32" maxlength="100" value="<?php echo e($model->description); ?>" />	
						<i class="name-edit fa fa-pencil"></i>
					</div>
				</fieldset>
			</div>
			
			<div class="submit_container">
				<span class="send-button cm-process-items">
					<i class="sendbt-icon fa fa-check"></i>
					<input type="submit" class="arrow-button" value="<?php echo e($create); ?>" onclick="onSubmit()" />
				</span>
				&nbsp;&nbsp;&nbsp;&nbsp;
				<span class="cancel-button cm-process-items">
					<i class="cancelbt-icon fa fa-times"></i>
					<input type="button" class="arrow-button" value="Cancel" onclick="return resetForm(this.form);" />
				</span>
			</div>
		<?php echo e(Form::close()); ?>

	</div>	
	
</div>

<div class="bottom-button" style="clear:both;">
	<span class="button-style cm-process-items" style="width:90%;text-align:right;margin:auto;margin-top:10px;">
		<?php if(isset($prev)): ?>
			<input type="button" class="arrow-button" onclick="location.href = '/backoffice/property/wizard/<?php echo e($prev); ?>';"  value="  Prev  " />
			&nbsp;&nbsp;&nbsp;&nbsp;
		<?php endif; ?>	
		<input type="button" class="arrow-button" onclick="location.href = '/backoffice/property/wizard/property';"  value="  Next  " />
	</span>						
</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backoffice.wizard.property.setting_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>