<?php $__env->startSection('leftsidebar'); ?>

<link href="/css/leftaside.css" rel="stylesheet">
<aside>

</aside>

<?php echo $__env->yieldSection(); ?>