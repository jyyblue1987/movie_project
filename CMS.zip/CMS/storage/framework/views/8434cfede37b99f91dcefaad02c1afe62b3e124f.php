            <div id="content_back">
            	<div class="left_title"></div>
                <div class="left_menu">
                	<div class="eachmenu" style="margin-top:67px;">
                    	<img src="/images/menu_icon_1.png"/>
                        <p>Property Setup</p>
                    </div>
                	<div class="eachmenu">
                    	<img src="/images/menu_icon_2.png"/>
                        <p>User Setup</p>
                    </div>
                	<div class="eachmenu">
                    	<img src="/images/menu_icon_3.png"/>
                        <p>Call Accounting Setup</p>
                    </div>
                	<div class="eachmenu">
                    	<img src="/images/menu_icon_4.png"/>
                        <p>Guest Services Setup</p>
                    </div>
                	<div class="eachmenu">
                    	<img src="/images/menu_icon_5.png"/>
                        <p>Syatem Level Setup</p>
                    </div>
                </div>
                <div class="right_block">
                	<div class="sel_page_group">
                        <div class="menu">
                        </div>
                        <div class="menu">
                        </div>
                        <div class="menu">
                        </div>
                        <div class="menu">
                        </div>
                        <div class="menu">
                        </div>
                        <div class="menu">
                        </div>
					</div>
                    <div class = "text_title1"><p>Hilton Hotels Middle East LTD</p></div>
                    <div class="search_back"></div>
                </div>
            </div>
         </div>
	</body>
</html>