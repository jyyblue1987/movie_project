<?php $__env->startSection('content'); ?>
	<section style="float:left;width:1159px;height:100%">
		<link href="/css/admin_setting.css" rel="stylesheet">
		<div id="setting_div">			
			<div id="setting_sidebar" class="sidebar_back">
				<?php echo $__env->make('backoffice.wizard.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			<div id="setting_content">
				<div id="setting_sub_content">
				<?php $__env->startSection('setting_nav'); ?>
					<div class="setting_menu_group" style="margin-left:155px;">
						<?php if($errors->any()): ?>
							<h4><?php echo e($errors->first()); ?></h4>
						<?php endif; ?>
						<?php 
							$path = 'backoffice/property/wizard';
							$selected = array();
							for( $i = 0; $i < 6; $i++ )
							{
								if( $i < $step )
									array_push($selected, 'selector');
								else
									array_push($selected, '');
							}
								
						?>			
					
						<div id="client" class="settingmenu <?php echo e($selected['0']); ?>">
							<span>					
								Client
							</span>		
						</div>						
						
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['0']); ?>"></span>	
						</div>						
						
						<div id="property" class="settingmenu <?php echo e($selected['1']); ?>">
							<span>						
								Property
							</span>
						</div>
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['1']); ?>"></span>	
						</div>						
						<div id="building" class="settingmenu <?php echo e($selected['2']); ?>">
							<span>						
								Building
							</span>
						</div>
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['2']); ?>"></span>	
						</div>						
						<div id="floor" class="settingmenu <?php echo e($selected['3']); ?>">
							<span>						
								Floor
							</span>
						</div>
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['3']); ?>"></span>	
						</div>						
						<div id="roomtype" class="settingmenu <?php echo e($selected['4']); ?>">
							<span>						
								Room Type
							</span>
						</div>
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['4']); ?>"></span>	
						</div>						
						<div id="room" class="settingmenu <?php echo e($selected['5']); ?>">
							<span>						
								Room
							</span>
						</div>
					</div>		
					<div style="clear:both;margin-top:150px;positive:relative">
						<?php echo $__env->yieldContent('setting_content'); ?>								
					</div>	
				<?php echo $__env->yieldSection(); ?>	
				
				</div>
			
			</div>	
		</div>	
	</section>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>