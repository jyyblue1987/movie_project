<?php $__env->startSection('content'); ?>
	<section style="float:left;width:100%;height:100%">
		<link href="/css/admin_setting.css" rel="stylesheet">
		<div id="setting_div">
			
			<div id="setting_sidebar" class="sidebar_back" style="background: #2c7796;">
				<?php echo $__env->make('layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			<div id="setting_content" style="background: url('/images/covers1.jpg');background-size: cover;">
				<div id="setting_sub_content" style="    border-color: #2c7796;    border-style: solid;">
				<?php $__env->startSection('setting_nav'); ?>
					<div style="clear:both;margin-top:50px;positive:relative">
						<?php echo $__env->yieldContent('setting_content'); ?>								
					</div>	
				<?php echo $__env->yieldSection(); ?>	
				
				</div>
			
			</div>	
		</div>	
	</section>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>