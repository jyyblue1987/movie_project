<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" href="/css/styles.css" type="text/css" media="screen" />
	<title>Client</title>
    <link href="/css/form.css" rel="stylesheet">
</head>

<script type="text/javascript">
	var centerIt = function (el /* (jQuery element) Element to center */) {
		if (!el) {
			return;
		}
		var moveIt = function () {
			var winWidth = $(window).width();
			var winHeight = $(window).height();
			el.css("position","absolute").css("left", ((winWidth / 2) - (el.width() / 2)) + "px").css("top", ((winHeight / 2) - (el.height() / 2)) + "px");
		}; 
		$(window).resize(moveIt);
		moveIt();
	};
</script>

<body>
	<div id = "total_div">
    	<div id="container">
            <div id = "top_back">
                <div class="icon"></div>
                <div class="subject"></div>
                <div id="setting">
                    <div class="setting_icon"></div>
                    <div class="setting_text"><p>Setting</p></div>
                </div>
            </div>
        </div>


