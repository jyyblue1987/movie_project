<?php $__env->startSection('content'); ?>
	<section style="float:left;width:100%;height:100%">
		<link href="/css/admin_setting.css" rel="stylesheet">
		<div id="setting_div">
			
			<div id="setting_sidebar" class="sidebar_back">
				<?php echo $__env->make('backoffice.wizard.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			<div id="setting_content">
				<div id="setting_sub_content">
				<?php $__env->startSection('setting_nav'); ?>
					<div class="setting_menu_group" style="margin-left:25%;width:60%">
						<?php if($errors->any()): ?>
							<h4><?php echo e($errors->first()); ?></h4>
						<?php endif; ?>
						<?php 
							$path = 'backoffice/property/wizard';
							$selected = array();
							for( $i = 0; $i < 4; $i++ )
							{
								if( $i < $step )
									array_push($selected, 'selector');
								else
									array_push($selected, '');
							}
								
						?>			
					
						<div id="department" class="settingmenu <?php echo e($selected['0']); ?>" style="font-size:10px;">
							<span style="font-size:10px;">					
								Department
							</span>		
						</div>						
						
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['0']); ?>"></span>	
						</div>						
						
						<div id="common" class="settingmenu <?php echo e($selected['1']); ?>">
							<span>						
								Common Area
							</span>
						</div>
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['1']); ?>"></span>	
						</div>						
						<div id="admin" class="settingmenu <?php echo e($selected['2']); ?>">
							<span>						
								Admin Area
							</span>
						</div>
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['2']); ?>"></span>	
						</div>						
						<div id="outdoor" class="settingmenu <?php echo e($selected['3']); ?>">
							<span>						
								Outdoor Area
							</span>
						</div>						
					</div>		
					<div style="clear:both;margin-top:150px;positive:relative">
						<?php echo $__env->yieldContent('setting_content'); ?>								
					</div>	
				<?php echo $__env->yieldSection(); ?>	
				
				</div>
			
			</div>	
		</div>	
	</section>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>