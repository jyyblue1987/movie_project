	<?php echo $__env->make('layout.topmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php $__env->startSection('content'); ?>
    <?php $__env->stopSection(); ?>
