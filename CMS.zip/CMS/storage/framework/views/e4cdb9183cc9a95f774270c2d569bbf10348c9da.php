<?php $__env->startSection('setting_sidebar'); ?>
<div class="left_menu">
	<div class="eachmenu" style="margin-top:67px;">
		<img src="/images/menu_icon_1.png"/>
		<p>Property Setup</p>
	</div>
	<div class="eachmenu">
		<img src="/images/menu_icon_2.png"/>
		<p>User Setup</p>
	</div>
	<div class="eachmenu">
		<img src="/images/menu_icon_3.png"/>
		<p>Call Accounting Setup</p>
	</div>
	<div class="eachmenu">
		<img src="/images/menu_icon_4.png"/>
		<p>Guest Services Setup</p>
	</div>
	<div class="eachmenu">
		<img src="/images/menu_icon_5.png"/>
		<p>Syatem Level Setup</p>
	</div>
</div>
<?php echo $__env->yieldSection(); ?>