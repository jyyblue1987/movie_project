<?php $__env->startSection('header'); ?>
<head>
	<meta charset="UTF-8">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	
	<title>Hotel Management</title>
	<link rel="stylesheet" href="/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="/bootstrap/css/bootstrap-theme.css">
	<link href="/css/form.css" rel="stylesheet">
	<link href="/css/color.css" rel="stylesheet">
	<link href="/css/dialog.css" rel="stylesheet">
	<link href="/css/styles.css" rel="stylesheet">
	<link href="/css/grid_view.css" rel="stylesheet">
	<link rel="stylesheet" href="/css/font-awesome.min.css">
	
	<!-- Checkbox -->
	<script type='text/javascript' src='/js/jquery.js'></script>
    <script type='text/javascript' src="/bootstrap/js/bootstrap.js"></script> 
	
	<!-- Upload -->
	<script type='text/javascript' src='/js/jquery.uploadfile.min.js'></script>
	<link rel="stylesheet" type="text/css" href="/css/uploadfile.css" />
	
	<!-- bootstrap switch-->
	<link href="/css/bootstrap-switch.css" rel="stylesheet">
	<script src="/js/bootstrap-switch.js"></script>
	
	<script src="/js/jquery-migrate-1.2.1.js"></script>
	<script type='text/javascript' src='/js/jquery.appear-1.1.1.js'></script>
	<script type='text/javascript' src='/js/core.js'></script>
	<script type='text/javascript' src='/js/ajax.js'></script>
	<script type='text/javascript' src='/js/funcs.js'></script>	
	<script type='text/javascript' src='/js/customize_ui.js'></script>	
	
	
	<script type="text/javascript">
		$.ajaxSetup({
		  headers: {
			'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
		  }
		});
		
		var changes_warning = 'Y';
        $(function(){
            $.runCart('A');
        });
		
	</script>
</head>
<?php echo $__env->yieldSection(); ?>
