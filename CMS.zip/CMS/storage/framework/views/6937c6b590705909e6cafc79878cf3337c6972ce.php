
<footer id="footer">
	<div class="container">
		<div class="row">
			<div class="col-lg-4">
				<h4>CONTACT US</h4>
				<p>
					+60 3-6258 8977<br/>
					support@hoya.com<br/>
					<br/>
					<br/>
				</p>
			</div><!-- /col-lg-4 -->

			<div class="col-lg-4">
				<h4>VISIT US</h4>
				<p>Malaysia Hoya Lens Sdn. Bhd<br/>
					No.6, Jalan 7/32A, Off 6 1/2 Miles,<br/>
					Jalan Kepong,<br/>
					52000 Kuala Lumpur,<br/>
					Malaysia<br/>
				</p>
			</div><!-- /col-lg-4 -->
			
			<div class="col-lg-4">
				<h4>MENU</h4>
				<p style="font-size:">
					<a href="#">About Us</a><br/>
					<a href="#">Products</a><br/>
					<a href="#">Lens Selector</a>
					<a href="#">Career</a><br/>
					<a href="#">Contact Us</a>
				</p>
			</div><!-- /col-lg-4 -->
			
		
		</div>
		<div class="row" style="width:100%; text-align:center;margin-top:30px">
			<p>Copyright @ 2015 Malaysian HOYA Sdn. Bhd. All rights reserved.</p>		
		</div>
	</div>
</footer>


