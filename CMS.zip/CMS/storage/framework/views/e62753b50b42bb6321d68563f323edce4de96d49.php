<?php $__env->startSection('content'); ?>

<?php

use App\Modules\Functions;

if( $error === 'SUCCESS' )
    Functions::alertSuccessMessage('');
else if( $error !== '' )
    Functions::alertErrorMessage ($error);

?>
<link rel="stylesheet" type="text/css" href="/css/jquery.datetimepicker.css"/>
<!--<script src="/js/jquery_2.js"></script>-->
<script src="/js/jquery.datetimepicker.full.js"></script>


<div id="main_column" class="clear">
	<div class="clear mainbox-title-container">
			<h1 class="mainbox-title float-left">
				新的广告图片 
			</h1>
  			
	</div>

	<div class="mainbox-body" >

<!--		<script type="text/javascript" src="/js/tabs.js"></script>-->

		<div class="cm-tabs-content">
			<?php 
				if($mode === 'create')
					$actionurl = '/admin/ad_item'; 
				else
					$actionurl = '/admin/update_ad_item/'.$adver->id;
			?>
			<form name="profile_form" action=<?php echo e($actionurl); ?> method="post" class="cm-form-highlight">
				<input type="hidden" name="region_data[mode]" value="" />
				<input type="hidden" name="region_data[thumb_url]" id="thumb_url" value="<?php echo e($adver->thumbpath); ?>" />

				<div id="content_general">
					<fieldset>
						<h2 class="subheader">
							图片信息
						</h2>

						<div class="form-field">
							<label for="regionname" class="cm-required">标题:</label>
							<input type="text" id="regionname" name="region_data[title]" class="input-text" size="36" maxlength="50" value="<?php echo e($adver->title); ?>" />
						</div>


						<div class="form-field hidden">
							<label class="cm-required">Start Date:</label>
							<div class="select-field">
								<input name="region_data[start]" id='datetimepicker1' size='30' style="font-size:16px" value="<?php echo e(date('Y-m-d')); ?>"/> 
							</div>
						</div>
						
						<div class="form-field hidden">
							<label class="cm-required">End Date:</label>
							<div class="select-field">
								<input name="region_data[end]" id='datetimepicker2' size='30' style="font-size:16px" value="<?php echo e(date('Y-m-d')); ?>"/> 
							</div>
						</div>
						<div class="form-field">
							<label for="regionname" class="cm-required">序列:</label>
							<input type="text" id="sequence" name="region_data[sequence]" class="input-text" size="10" maxlength="50" value="<?php echo e($adver->sequence); ?>" />
						</div>
						<div class="form-field " id="div_thumb">
							<label class="cm-required ">上传广告图片:</label>
							<table border="0">
								<tr>
									<td width="400px">
										<div id="mulitplethumbploader">上传</div>
									</td>
									<td valign="middle">
										<div><font color="blue">( Max size: 100MB (Width:Height=3:2) , *.jpg, *.png)</font></div>
									</td>
								</tr>
								<tr>
									<td width="400px">
										<div id="status1"><?php echo e($adver->thumbpath); ?></div>
									</td>
									<td></td>
								</tr>
							</table>
						</div>


					</fieldset>

				</div>

				<?php 
					if($mode === 'create')
						$label = '创新';
					else
						$label = '保存';
				?>
				<div class="buttons-container buttons-bg cm-toggle-button">
					<span  class="submit-button cm-button-main ">
						<input   type="submit" name="dispatch[profiles.update]" value="<?php echo e($label); ?>" />
					</span>
					&nbsp;&nbsp;&nbsp;
					<span class="cm-button-main cm-process-items">
						<input type="button" onclick="location.href='/admin/advertisement';"  value="取消" />
					</span>
				</div>


			</form>
		</div>
	</div>
</div>

<script>
	$(document).ready(function(){
		$("#status1").html("<div></div>");
		var settings = {
			url: "/models/file_upload.php",
			dragDrop: false,
			fileName: "myfile",
			multiple: false,
			showCancel: false,
			showAbort: false,
			showDone: false,
			showDelete:false,
			showError: true,
			showStatusAfterSuccess: false,
			showStatusAfterError: false,
			showFileCounter:false,
			allowedTypes: "jpg,png",
			maxFileSize: 112000000,
			returnType: "text",
			onSuccess: function(files, data, xhr)
			{
				$("#thumb_url").val(data);
				$("#status1").html("<div>" + data + "</div>");
			},
			 deleteCallback: function(data, pd)
			{
				for (var i = 0; i < data.length; i++)
				{
					$.post("file_delete.php", {op: "delete", name: data[i]},
					function(resp, textStatus, jqXHR)
					{
						//Show Message
						
						$("#status1").html("<div>File Deleted</div>");
					});
				}
				pd.statusbar.hide(); //You choice to hide/not.
			} 
		};
		$("#mulitplethumbploader").uploadFile(settings);
	});
</script>

<script>

$('#datetimepicker1').datetimepicker({
	lang:'ch',
	timepicker:false,
	format:'Y-m-d',
	formatDate:'Y/m/d'
});

$('#datetimepicker2').datetimepicker({
	lang:'ch',
	timepicker:false,
	format:'Y-m-d',
	formatDate:'Y/m/d'
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>