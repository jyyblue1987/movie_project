<?php $__env->startSection('content'); ?>
	<section style="float:left;width:1159px;height:100%">
		<link href="/css/admin_setting.css" rel="stylesheet">
		<div id="setting_div">			
			<div id="setting_sidebar" class="sidebar_back">
				<?php echo $__env->make('backoffice.wizard.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			<div id="setting_content">
				<div id="setting_sub_content">
				<?php $__env->startSection('setting_nav'); ?>
					<div class="setting_menu_group" style="margin-left:55px;width:90%">
						<?php if($errors->any()): ?>
							<h4><?php echo e($errors->first()); ?></h4>
						<?php endif; ?>
						<?php 
							$selected = array();
							for( $i = 0; $i < 10; $i++ )
							{
								if( $i < $step )
									array_push($selected, 'selector');
								else
									array_push($selected, '');
							}
								
						?>			
					
						<div id="departfunc" class="settingmenu <?php echo e($selected['0']); ?>">
							<span>					
								Department function
							</span>		
						</div>						
						
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['0']); ?>"></span>	
						</div>						
						
						<div id="location_group" class="settingmenu <?php echo e($selected['1']); ?>">
							<span>						
								Location groups
							</span>
						</div>
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['1']); ?>"></span>	
						</div>						
						<div id="escalation" class="settingmenu <?php echo e($selected['2']); ?>">
							<span>						
								Escalation
							</span>
						</div>
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['2']); ?>"></span>	
						</div>						
						<div id="task" class="settingmenu <?php echo e($selected['3']); ?>">
							<span>						
								Task
							</span>
						</div>
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['3']); ?>"></span>	
						</div>						
						
						<div id="minibar" class="settingmenu <?php echo e($selected['4']); ?>">
							<span>						
								Minibar
							</span>
						</div>
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['4']); ?>"></span>	
						</div>		
						
						<div id="housekeeping" class="settingmenu <?php echo e($selected['5']); ?>">
							<span>						
								House keeping
							</span>
						</div>
						
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['5']); ?>"></span>	
						</div>		
						
						<div id="device" class="settingmenu <?php echo e($selected['6']); ?>">
							<span>						
								Device
							</span>
						</div>
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['6']); ?>"></span>	
						</div>		
						
						<div id="shifts" class="settingmenu <?php echo e($selected['7']); ?>">
							<span>						
								Shifts
							</span>
						</div>
						<div class="settingmenu_div">
							<span class="linediv <?php echo e($selected['7']); ?>"></span>	
						</div>		
						
						<div id="alara" class="settingmenu <?php echo e($selected['8']); ?>">
							<span>						
								Alarms
							</span>
						</div>						
						
					</div>		
					<div style="clear:both;margin-top:150px;positive:relative">
						<?php echo $__env->yieldContent('setting_content'); ?>								
					</div>	
				<?php echo $__env->yieldSection(); ?>	
				
				</div>
			
			</div>	
		</div>	
	</section>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>