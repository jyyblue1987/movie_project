<?php $__env->startSection('topmenu'); ?>
<link href="/css/topmenu.css" rel="stylesheet">
<header>
	<div id = "top_back">
		<div class="icon"></div>
		<div class="subject"></div>
		<div id="setting">
			<div class="setting_icon"></div>
			<div class="setting_text"><p>Setting</p></div>
		</div>
	</div>
</header>

<?php echo $__env->yieldSection(); ?>