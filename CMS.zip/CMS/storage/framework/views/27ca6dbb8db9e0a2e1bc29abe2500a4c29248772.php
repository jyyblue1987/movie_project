<!doctype html>
<html lang="en">

	<?php echo $__env->make('layout.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<body align="center">

		<div id = "total_div" style="display:none;">
			<div id="content_back">				
				<?php echo $__env->yieldContent('content'); ?>				
			</div>
		</div>

	</body>
	
	<script>
	$(function () {
		var screenwidth = window.innerWidth;
		var screenheight = window.innerHeight;	
		var margin = (screenwidth - 700) / 2;
		$('#total_div').css('margin-left', margin+'px');
		$('#total_div').css('width', '700px');
		$('#total_div').css('display', 'block');
	});
	</script>
</html>