<?php $__env->startSection('content'); ?>
	<section style="float:left;width:1159px;height:100%">
		<link href="/css/admin_setting.css" rel="stylesheet">
		<div id="setting_div">
			
			<div id="setting_sidebar" class="sidebar_back">
				<?php $__env->startSection('setting_sidebar'); ?>
				<div class="left_menu">
					
					<div class="eachmenu" style="margin-top:47px;margin-left:0px;">
						
						<p id="setup_wizard"><i class="fa fa-gear" style="width:25px;font-size:25px"></i><span style="margin-top:-5px;font-size:15px;font-weight:bold;">&nbsp;&nbsp;SETUP WIZARD<span></p>
					</div>
					<div class="eachmenu" style="margin-top:37px;">
						<img src="/images/menu_icon_1.png"/>
						<p>Property Setup</p>
					</div>
					<div class="eachmenu">
						<img src="/images/menu_icon_2.png"/>
						<p>User Setup</p>
					</div>
					<div class="eachmenu">
						<img src="/images/menu_icon_3.png"/>
						<p>Call Accounting Setup</p>
					</div>
					<div class="eachmenu">
						<img src="/images/menu_icon_4.png"/>
						<p>Guest Services Setup</p>
					</div>
					<div class="eachmenu">
						<img src="/images/menu_icon_5.png"/>
						<p>Syatem Level Setup</p>
					</div>
				</div>
				<?php echo $__env->yieldSection(); ?>	
			</div>
			<div id="setting_content">
			<?php $__env->startSection('setting_nav'); ?>
				<div class="setting_menu_group">
					<a href="/admin/setting/client">
						<div id="client" class="settingmenu">
							<span>					
								Client
							</span>		
						</div>						
					</a>
					<a href="">
						<div id="client" class="settingmenu_div">
							<span class="linediv"></span>	
						</div>						
					</a>
					<a href="/admin/setting/property">
						<div id="property" class="settingmenu">
							<span>						
								Property
							</span>
						</div>
					</a>
					<a href="">
						<div id="client" class="settingmenu_div">
							<span class="linediv"></span>	
						</div>						
					</a>
					<a href="/admin/setting/building">
						<div id="building" class="settingmenu">
							<span>						
								Building
							</span>
						</div>
					</a>
					<a href="">
						<div id="client" class="settingmenu_div">
							<span class="linediv"></span>	
						</div>						
					</a>
					<a href="/admin/setting/floor">
						<div id="floor" class="settingmenu">
							<span>						
								Floor
							</span>
						</div>
					</a>
					<a href="">
						<div id="client" class="settingmenu_div">
							<span class="linediv"></span>	
						</div>						
					</a>
					<a href="/admin/setting/room">
						<div id="room" class="settingmenu">
							<span>						
								Rooms
							</span>
						</div>
					</a>
					<a href="">
						<div id="client" class="settingmenu_div">
							<span class="linediv"></span>	
						</div>						
					</a>
					<a href="/admin/setting/confirm">
						<div id="confirm" class="settingmenu">
							<span>						
								Client
							</span>
						</div>
						
					</a>				
				</div>		
				<div>
					<?php echo $__env->yieldContent('setting_content'); ?>		
					
					<div style="clear:both">
						<div style="width:90%;text-align:right;margin:auto;margin-top:10px;">
							<a href="/admin/setting/<?php echo e($next); ?>"><img src="/images/admin/next_btn_bg.png" width=120px height=35px/></a>
						</div>
					</div>
				</div>	
			<?php echo $__env->yieldSection(); ?>	
			
			</div>
			
		</div>		
	</section>
	<script type="text/javascript">
	    $(document).ready(function($){
			$("#<?php echo e($step); ?>").addClass("selector");
	    });

	</script>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>