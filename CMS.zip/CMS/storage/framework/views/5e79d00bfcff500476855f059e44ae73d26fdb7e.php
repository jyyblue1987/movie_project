<?php $__env->startSection('leftsidebar'); ?>

<link href="/css/leftaside.css" rel="stylesheet">


<?php echo $__env->yieldSection(); ?>