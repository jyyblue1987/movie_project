<?php $__env->startSection('setting_content'); ?>
<?php	
	$title = "ROOM";	
	
	$current_url = '/backoffice/property/wizard/property';	
	$param = "";
	if( !empty($_SERVER["QUERY_STRING"]) )
		$param = '?' . $_SERVER["QUERY_STRING"];
?>
<div class="item_container" style="margin:auto;height:600px">
	<div class="items">		
		<span style="float:left;margin-left:10px;margin-top:10px">
		<?php echo e($title); ?>

		</span>
		
		<span class="delete-button"  style="float:right;margin-top:7px;margin-right:2px;background:#648CA9; border-radius:3px;border:1px solid;border-color:#ccc;">
			<i class="editbt-icon fa fa-pencil"></i>
			<input type="button" class="arrow-del-button" value="Add" onclick="location.href = '/backoffice/property/wizard/property/create'" />
		</span>
	</div>		
		
	<div class="form_center">		
		<?php 
			$start = ($datalist->currentPage() - 1) * $datalist->perPage() + 1; 
			$end = $start + $datalist->count() - 1 
		?>	
		<form action="<?php echo e($current_url); ?>" method="GET">
			<div id="data_grid_view" class="grid-view" style="width:99%;height:450px;margin-left:3px;margin-right:6px;margin-top:30px">
				<table class="items">
					<thead>
						<tr>
							<th width="1%" class="center cm-no-hide-input">
								<input type="checkbox" name="check_all" value="Y" title="Check / uncheck all" class="checkbox cm-check-items" />
							</th>
							<th width="10%">#</th>
							<th width="10%">Property</th>
							<th width="10%">Client</th>
							<th width="15%">Address</th>
							<th width="15%">City</th>
							<th width="15%">Country</th>
							<th width="15%">Contact Person</th>
							<th width="15%">Mobile No</th>
							<th width="15%">Modules</th>
							<th class="button-column" id="data_grid_view_c8">
								<?php echo Form::select('pagesize', array('10' => '10', '20' => '20', '50' => '50', '100' => '100'), $pagesize, array('onchange' => 'this.form.submit()', 'style' => 'width:auto', 'class'=>'select-form')); ?>									
							</th>
						</tr>
					</thead>	
					<tbody>
						<?php $i = 1; ?>	
						<?php foreach( $datalist as $value ): ?>	
							<tr class="odd">
								<td class="center cm-no-hide-input">
									<input type="checkbox" name="ids[]" value=<?php echo e($value['id']); ?>" class="checkbox cm-item" />
								</td>
								<?php $no = $i + $start - 1; ?>
								<td> <?php echo e($no); ?></td>
								<td >
									<a href="<?php echo e($current_url); ?>/<?php echo e($value['id']); ?>/edit"><span><?php echo e($value['name']); ?></span></a>
								</td>		
								<td >
									<?php echo e($value->client['name']); ?>

								</td>	
								<td >
									<?php echo e($value['address']); ?>

								</td>
								<td >
									<?php echo e($value['city']); ?>

								</td>
								<td >
									<?php echo e($value['country']); ?>

								</td>
								<td >
									<?php echo e($value['contact']); ?>

								</td>
								<td >
									<?php echo e($value['mobile']); ?>

								</td>
								<td >
									<?php echo e($value['modules']); ?>

								</td>
								<td class="nowrap">
									<a class="tool-link " href="<?php echo e($current_url); ?>/<?php echo e($value['id']); ?>/edit<?php echo e($param); ?>" >Edit</a>
									&nbsp;&nbsp;|
									<ul class="cm-tools-list tools-list">
										<li><a class="cm-confirm" href="<?php echo e($current_url); ?>/delete/<?php echo e($value['id']); ?><?php echo e($param); ?>">Delete</a></li>
									</ul>

								</td>
							</tr>
							<?php $i++; ?>
						<?php endforeach; ?>
						
						<?php if($datalist->total() === 0): ?>
							<tr class="no-items">
								<td class="center cm-no-hide-input" colspan="7">
									<p>No Property List.</p>
								</td>
							</tr>
						<?php endif; ?>
					</tbody>	
				</table>	
			</div>
		</form>
		
	</div>	
	
</div>

<div class="bottom-button" style="clear:both;">
	<span class="button-style cm-process-items" style="width:90%;text-align:right;margin:auto;margin-top:10px;">
		<input type="button" class="arrow-button" onclick="location.href = '/backoffice/property/wizard/client';"  value="  Prev  " />
	</span>	&nbsp;&nbsp;&nbsp;&nbsp;
	<span class="button-style cm-process-items" style="width:90%;text-align:right;margin:auto;margin-top:10px;">
		<input type="button" class="arrow-button" onclick="location.href = '/backoffice/property/wizard/building';"  value="  Next  " />
	</span>						
</div>


<script type="text/javascript">
	
	
	
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.setting_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>