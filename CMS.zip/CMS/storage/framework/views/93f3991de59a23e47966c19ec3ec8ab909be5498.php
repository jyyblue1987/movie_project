<?php $__env->startSection('setting_content'); ?>

	<div style="clear:left;">
		<select name="category_id" style="float:left;margin-left:42px; margin-top:10px;position:relative;">
			<option value="0" selected="selected">First Floor</option>
			<option value="1">Second Floor</option><option value="2">Third Floor</option>
			<option value="3">Forth Floor</option><option value="4">Forth Floor</option>
		</select>	
	</div>
	<div style="clear:both">
		<div class="search_container" style="float:right;margin-top:10px">
			<input class="search_box sidebar_back white_color" type="text" size="15" name="search" id="search" value=""/>
			<img src="/images/admin/search_icon.png" class="input_img">
		</div>	
	</div>
	
	<div style="margin-top:50px;">
		<div class="item_container" style="margin:auto;height:300px;">
			<div class="item_container" style="width:50%;height:100%;float:left">
				<table width=100% class="items">
					<thead>
						<tr class="table_header">
							<th><a>Room Type</a></th>					
						</tr>
					</thead>
					<tbody>
						<tr class="odd">
							<th><a>All(8)</a></th>					
						</tr>
						<tr class="even">
							<th><a>Dusit Thani Group</a></th>					
						</tr>
						<tr class="odd">
							<th><a>Hilton Hotels Middle East LTD</a></th>					
						</tr>
						<tr class="even">
							<th><a>Intercontinental</a></th>					
						</tr>
						<tr class="odd">
							<td><a class="add_item"><img src="/images/admin/add_item_icon.png" onclick="add_item()"/></a></td>					
						</tr>
				
					</tbody>
				</table>
			</div>
			
			<div class="item_container" style="width:50%;height:100%;float:left">
				<table width=100% class="items">
					<thead>
						<tr class="table_header">
							<th><a>Room number</a></th>					
						</tr>
					</thead>
					<tbody>
						<tr class="odd">
							<td><a href="#openModal" class="add_item"><img src="/images/admin/add_orrange_icon.png"/></a></td>					
						</tr>	
						<tr class="even">
							<td><a>Dusit Thani Group</a></td>					
						</tr>
						<tr class="odd">
							<td><a>Hilton Hotels Middle East LTD</a></td>					
						</tr>
											
					</tbody>
				</table>
			</div>
		</div>	
	</div>
	
	<div class="form_item" style="float:right;margin-right:42px;color:#fff">							
		<input type="text" class="file" style="float:left;margin-left:50px;color:#fff" id="floorfile" name="floorfile" value="" READONLY />
		<div class="floor_upload">Choose file..</div>							
	</div>	
	
	
	<div id="openModal" class="modalDialog">
		<div>
			<a href="#close" title="Close" class="close">X</a>
			<p >Add New Room</p>
			<?php echo e(Form::open(array('url' => '#', 'method' => 'post' ))); ?>				
				<fieldset>
					<div class="form_item">
						<input id="individaulroom" type="radio" name="radio" value="1" checked="checked"><label for="individaulroom"><span><span></span></span>Add individual room</label>
					</div>	
					<div class="form_item">
						<select name="category_id" style="background:#2f2e2e;margin-left:50px">
							<option value="0" selected="selected">-- All Category --</option>
							<option value="1">Shoes</option><option value="2">Baby Stuff</option>
							<option value="3">Dress</option><option value="4">Shirts</option>
						</select>	
						<input type="text" name="room_num" value="10" size="7" style="background:#b1b2af;margin-left:10px"/>
						<a class="add_item"><img src="/images/admin/add_green_icon.png" style="position:absolute;margin-top:2px;"/></a>
					</div>	
					<div class="form_item">
						<input id="multiroom" type="radio" name="radio" value="2"><label for="multiroom"><span><span></span></span>Add multiple rooms</label>
					</div>	
					<div class="form_item">							
						<input type="text" class="file" style="float:left;margin-left:50px" accept="file/csv, file/xls, file/xlsx" id="roomfile" name="roomfile" value="" READONLY />
						<div class="room_upload">Choose file..</div>							
					</div>	
				</fieldset>
				<div class="form_item" style="text-align:center">						
					<span class="button">
						<input type="button" class="imgClass" value="Save" onclick="location.href = '#close'" />							
					</span>
					&nbsp;&nbsp;&nbsp;
					<span class="button">
						<input type="button" class="imgClass" value="Cancel" onclick="location.href = '#close'" />														
					</span>
				</div>	
				
			<?php echo e(Form::close()); ?>

		</div>
	</div>
	
	
	
	<script type="text/javascript">
	var roomupload = {
        url: "/upload",				
        dragDrop: false,
        fileName: "myfile",
        multiple: false,
        showCancel: false,
        showAbort: false,
        showDone: false,
        showDelete: false,
        showError: true,
        showStatusAfterSuccess: false,
        showStatusAfterError: false,
        showFileCounter: false,
        allowedTypes: "csv",
        maxFileSize: 5120000,
        returnType: "text",
        onSuccess: function(files, data, xhr)
        {
            $("#roomfile").val(data);
			console.log(data);
        },
        deleteCallback: function(data, pd)
        {   
			console.log(data);        
        }
    }
	
	$(".room_upload").uploadFile(roomupload);
	
	var floorupload = {
        url: "/upload",		
        dragDrop: false,
        fileName: "myfile",
        multiple: false,
        showCancel: false,
        showAbort: false,
        showDone: false,
        showDelete: false,
        showError: true,
        showStatusAfterSuccess: false,
        showStatusAfterError: false,
        showFileCounter: false,
        allowedTypes: "csv",
        maxFileSize: 5120000,
        returnType: "text",
        onSuccess: function(files, data, xhr)
        {
            $("#floorfile").val(data);
			console.log(data);
        },
        deleteCallback: function(data, pd)
        {   
			console.log(data);        
        }
    }
	
	$(".floor_upload").uploadFile(floorupload);
	
	
</script>

	
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.setting.setting_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>